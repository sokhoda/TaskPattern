package com.epam.champions.factory;

public abstract class BaseFactory {
    public abstract Circle createCircle();
    public abstract Triangle createTriangle();
}
