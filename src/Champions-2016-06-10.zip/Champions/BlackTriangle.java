package com.epam.champions.factory;

public class BlackTriangle extends Triangle {

	private Color color = Color.BLACK;
	
	public BlackTriangle(int a, int b, int c){
		super(a,b,c);
	}
	
	@Override
	public void draw(){
		System.out.println("Shape is " + color.name() + " with P = " + getPerimetr() + "and S =" + getSquare());
	}
	
	@Override
	public String toString(){
		 return "I am black triangle!";
	}
	
}
