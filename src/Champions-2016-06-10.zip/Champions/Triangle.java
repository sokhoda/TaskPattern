package com.epam.champions.factory;

/**
 * Created by Comandante on 08.06.2016.
 */
public abstract class Triangle {

    private int side1;
    private int side2;
    private int side3;

    Triangle(int ab, int bc, int ca){
        if (ab <= 0 || bc <= 0 || ca <= 0
                ||(ab + bc > ca)
                || (bc + ca > ab)
                || (ca + ab > bc))
            throw new IllegalArgumentException();
        this.side1 = ab;
        this.side2 = bc;
        this.side3 = ca;
    }

    public int getPerimetr(){
        return side1 + side2 + side3;
    }

    public int getSquare(){
        int half = getPerimetr()/2;
        return (int) Math.sqrt(half*(half-side1)*(half-side2)*(half-side3));
    }

    public abstract void draw();

}
