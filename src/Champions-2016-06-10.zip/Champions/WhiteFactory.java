package com.epum.champions;

public class WhiteFactory extends BaseFactory {

	@Override
	public Circle createCircle() {
		return new BlackCircle();
	}

	@Override
	public Triangle createTriangle() {
		return new WhiteTriangle();
	}
}
