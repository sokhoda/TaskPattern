package com.epam.champions.factory;

public class WhiteTriangle extends Triangle {

	private Color color = Color.WHITE;
	
	public WhiteTriangle(int a, int b, int c){
		super(a,b,c);
	}
	
	@Override
	public void draw(){
		System.out.println("Shape is " + color.name() + " with P = " + getPerimetr() + "and S =" + getSquare());
	}
	
	@Override
	public String toString(){
		 return "I am white triangle!";
	}
}
