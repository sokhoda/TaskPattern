package com.epam.champions.factory;

public class AbstractFactory {
   public static BaseFactory getFactory(Color color){
       if(color.equals(Color.WHITE)){
           return new WhiteFactory();
       }
       if(color.equals(Color.BLACK)){
           return new BlackFactory();
       }
       return null;
   }
}
