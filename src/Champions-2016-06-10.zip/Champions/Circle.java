/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.epam.champions.factory;

/**
 *
 * @author User
 */
public abstract class Circle {
    double radius;
    Color color;
    
    void setRadius(double radius){
        this.radius = radius;
    }
    
    double getRadius(){
        return this.radius;
    }
   
    void draw(){
        System.out.println("Circle " + radius + " mm");
    }
}
