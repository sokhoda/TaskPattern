package com.epam.champions.factory;

public enum Color {
  WHITE, BLACK;  
}
