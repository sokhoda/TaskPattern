/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.epam.champions.factory;

//import java.awt.Color;
/**
 *
 * @author User
 */
public class WhiteCircle extends Circle{
    
    Color color; 
    
    WhiteCircle(){
        color = Color.WHITE;
    }
    
    Color getColor(){
        return color;
    }
    
    @Override
    public void draw(){
        System.out.println(color + " circle " + radius + "mm");
    }
    
}
